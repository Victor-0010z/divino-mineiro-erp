"use client";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  BarChart3,
  Bell,
  Bike,
  LayoutDashboard,
  ListTodo,
  LogOut,
  Menu,
  ReceiptText,
  ScrollText,
  Settings,
  ShoppingCart,
  Truck,
  UserCog,
  UsersRound,
  X,
} from "lucide-react";
import {
  encerrarSessao,
  obterSessao,
  type SessaoUsuario,
} from "@/lib/services/auth-service";
import { cn, iniciais } from "@/lib/utils";
const itens = [
  ["/dashboard", "Visão geral", LayoutDashboard],
  ["/contas", "Contas a pagar", ReceiptText],
  ["/diaristas", "Diaristas", UsersRound],
  ["/motoboys", "Motoboys", Bike],
  ["/fornecedores", "Fornecedores", Truck],
  ["/compras", "Solicitações", ShoppingCart],
  ["/tarefas", "Tarefas", ListTodo],
  ["/relatorios", "Relatórios", BarChart3],
  ["/usuarios", "Usuários", UserCog],
  ["/auditoria", "Auditoria", ScrollText],
  ["/configuracoes", "Configurações", Settings],
] as const;
export function AppShell({ children }: { children: React.ReactNode }) {
  const path = usePathname(),
    router = useRouter();
  const [sessao, setSessao] = useState<SessaoUsuario | null>(null),
    [menu, setMenu] = useState(false);
  useEffect(() => {
    const s = obterSessao();
    if (!s) router.replace("/login");
    else setSessao(s);
  }, [router]);
  if (!sessao)
    return (
      <div className="grid min-h-screen place-items-center">Carregando...</div>
    );
  const nav = (
    <>
      <div className="flex h-24 items-center border-b px-4">
        <span className="relative h-16 w-40">
          <Image
            src="/divino-logo.png"
            alt="Logo Divino Mineiro"
            fill
            className="object-contain object-left"
          />
        </span>
        <button className="ml-auto lg:hidden" onClick={() => setMenu(false)}>
          <X />
        </button>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto p-3">
        {itens
          .filter(
            ([href]) =>
              sessao.usuario.perfil === "ADMINISTRADOR" ||
              !["/usuarios", "/auditoria", "/configuracoes"].includes(href),
          )
          .map(([href, label, Icon]) => (
            <Link
              key={href}
              href={href}
              onClick={() => setMenu(false)}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                path === href
                  ? "bg-primary text-white shadow-sm"
                  : "text-foreground/65 hover:bg-orange-50 hover:text-primary",
              )}
            >
              <Icon size={18} />
              {label}
            </Link>
          ))}
      </nav>
      <div className="border-t p-4">
        <div className="mb-3 flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-primary/10 text-xs font-bold text-primary">
            {iniciais(sessao.usuario.nome)}
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">
              {sessao.usuario.nome}
            </p>
            <p className="text-xs text-foreground/50">
              {sessao.usuario.perfil === "ADMINISTRADOR"
                ? "Administrador"
                : "Gerência"}
            </p>
          </div>
        </div>
        <button
          className="btn-outline w-full"
          onClick={() => {
            encerrarSessao();
            router.push("/login");
          }}
        >
          <LogOut size={16} />
          Sair
        </button>
      </div>
    </>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[250px_1fr]">
      <aside className="hidden border-r bg-card lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col">
        {nav}
      </aside>
      {menu && (
        <div
          className="fixed inset-0 z-50 bg-black/40 lg:hidden"
          onClick={() => setMenu(false)}
        >
          <aside
            className="flex h-full w-[280px] flex-col bg-card"
            onClick={(e) => e.stopPropagation()}
          >
            {nav}
          </aside>
        </div>
      )}
      <div>
        <header className="sticky top-0 z-30 flex h-16 items-center border-b bg-background/90 px-4 backdrop-blur md:px-7">
          <button onClick={() => setMenu(true)} className="mr-3 lg:hidden">
            <Menu />
          </button>
          <div>
            <p className="text-xs text-foreground/50">Divino Mineiro ERP</p>
            <b className="text-sm">Gestão interna</b>
          </div>
          <button
            aria-label="Notificações"
            className="notification-button ml-auto"
          >
            <Bell className="bell" size={18} />
            <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-red-500" />
          </button>
        </header>
        <main className="p-4 md:p-7">{children}</main>
      </div>
    </div>
  );
}
